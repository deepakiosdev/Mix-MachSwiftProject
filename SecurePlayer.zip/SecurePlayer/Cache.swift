//
//  Cache.swift
//  SecurePlayer
//
//  Created by Sharad Rao on 20/09/16.
//  Copyright © 2016 Sharad Rao. All rights reserved.
//

import UIKit


class Cache: NSObject {

    open class func getKey() -> NSString? {
         return "54G91A8?s7^F97C]Fyj*8&kR2eU+HNg!"
    }
    
}
