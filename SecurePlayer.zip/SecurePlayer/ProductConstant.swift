//
//  ProductConstant.swift
//  SecurePlayer
//
//  Created by Sharad Rao on 16/09/16.
//  Copyright © 2016 Sharad Rao. All rights reserved.
//

import Foundation

let CONFIG = "Secure Player"
