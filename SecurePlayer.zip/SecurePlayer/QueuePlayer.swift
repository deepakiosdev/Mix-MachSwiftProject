//
//  QueuePlayer.swift
//  SecurePlayer
//
//  Created by Sharad Rao on 16/09/16.
//  Copyright © 2016 Sharad Rao. All rights reserved.
//

import UIKit
import AVFoundation

// Contexts for KVO
private var kAirplayKVO:UnsafeMutableRawPointer?
private var kBufferEmptyKVO:UnsafeMutableRawPointer?
private var kStatusDidChangeKVO:UnsafeMutableRawPointer?
private var kTimeRangesKVO:UnsafeMutableRawPointer?
private var kBufferKeepup:UnsafeMutableRawPointer?

@objc protocol QueuePlayerDelegate:NSObjectProtocol
{
   @objc optional func playerInitialised(player:CLong)
   @objc optional func playerInitialisedFailed(player:CLong)
   @objc optional func playerDidPause(player:CLong)
   @objc optional func playerDidResumePlay(player:CLong)
    
}

class QueuePlayer: UIView, AVAssetResourceLoaderDelegate {

    var framesPerSecond:Float = 0

    private weak var delegate:QueuePlayerDelegate?
    private var player:AVQueuePlayer? {
        set
        {
            let layer = self.layer as! AVPlayerLayer
            layer.player = self.player
        }
        get
        {
            let playLayer = self.layer as! AVPlayerLayer
            return  playLayer.player as! AVQueuePlayer?
        }
    }
    private var playerLayer:AVPlayerLayer? {
        get{
            return self.layer as? AVPlayerLayer
        }
    }
    private var playerTimeObserver:AnyObject?
    private var duration:CMTime?
    private var framerateFractionalValue:Float64? = 0.0
    private var playSpeedRate:Float?
    
    required init?(coder aDecoder: NSCoder)
    {
        super.init(coder: aDecoder)
        self.setUpPlayer()
    }
    
    func setUpPlayer() -> Void
    {
        self.playerLayer?.opacity = 1.0
        self.playerLayer?.videoGravity = AVLayerVideoGravityResizeAspect
        self.playerLayer?.needsDisplayOnBoundsChange = true
        
        if framesPerSecond == 0 {
            framesPerSecond = 25.0
        }
        framerateFractionalValue = 0.2
        playSpeedRate = 1.0
        
        self.player = AVQueuePlayer.init()
    }
    
    func initWithURLString(url:NSString?, andDelegate delegate:AnyObject?) -> Void {
        if (url != nil) {
            self.initWithURLList(list: [url!], andDelegate: delegate)
        }
    }
    
    func initWithURLList(list:[AnyObject]?, andDelegate delegate:AnyObject?) -> Void
    {
        self.reloadItems(urlArray:list)
        self.setPlayback(rate: 1.0)
        self.addObserver()
    }
    
    func setPlayback(rate:Float) -> Void
    {
        if (rate != playSpeedRate) {
            playSpeedRate = rate
        }
    }
    
    private func reloadItems(urlArray:[AnyObject]?) -> Void
    {
        self.player?.pause()
        self.player?.removeAllItems()
        
        for urlString in urlArray!
        {
            var urlStr = urlString as! NSString
            if urlStr.range(of:".m3u8").location == NSNotFound {
                urlStr = urlStr.replacingOccurrences(of:"http", with:"playlist") as NSString
            }
            print("Streming URL:",urlStr)
            
            let headers = NSMutableDictionary()
            headers.setObject("iPad", forKey:"User-Agent" as NSCopying)
            
            let url = URL.init(string:urlStr as String)
            let assetUrl = AVURLAsset(url:url!, options: ["AVURLAssetHTTPHeaderFieldsKey":headers])
            let resourceLoader = assetUrl.resourceLoader
            resourceLoader .setDelegate(self, queue:DispatchQueue(label:"CMQueuePlayerAsset loader"))
            
            let playerItem = AVPlayerItem(asset: assetUrl)
            
            if (self.player?.canInsert(playerItem, after: nil))! {
                self.player?.insert(playerItem, after: nil)
            }
        }
        
    }
    
    override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?)
    {
        let playerStatus:AVPlayerItemStatus = (self.player?.currentItem?.status)!
        if (context == kStatusDidChangeKVO)
        {
            if playerStatus == AVPlayerItemStatus.readyToPlay
            {
                if framesPerSecond == 0 {
                }
                if (self.delegate?.responds(to:Selector.init(("playerInitialised:"))))! {
                    self.delegate?.playerInitialised!(player: self.tag)
                }
            }
        }
        else if (context == kBufferEmptyKVO)
        {
            if (self.delegate?.responds(to:Selector.init(("playerDidPause:"))))! {
                self.delegate?.playerDidPause!(player:self.tag)
            }
        }
        else if (context == kTimeRangesKVO)
        {
            let timeRanges = ((change! as NSDictionary).object(forKey: NSKeyValueChangeKey.newKey)) as! NSArray
            if (timeRanges.isKind(of: NSNull.self) && timeRanges.count > 0)
            {
                let timeRange:CMTimeRange = (timeRanges[0] as! NSValue).timeRangeValue
                let bufferSeconds:Float64 = CMTimeGetSeconds(CMTimeAdd(timeRange.start, timeRange.duration))
                if bufferSeconds > 5.0
                {
                    if (self.delegate?.responds(to:Selector.init(("playerDidResumePlay:"))))! {
                        self.delegate?.playerDidResumePlay!(player:self.tag)
                    }
                }
                
            }
            
        }
        else {
            
        }
    }
    
    
    func resourceLoader(_ resourceLoader: AVAssetResourceLoader, shouldWaitForLoadingOfRequestedResource loadingRequest: AVAssetResourceLoadingRequest) -> Bool
    {
        let scheme = (loadingRequest.request.url?.scheme)! as NSString
        if ((scheme.range(of: "playlist").location != NSNotFound))
        {
            var customUrl:NSString? = loadingRequest.request.url?.absoluteString as NSString?
            var urlString = customUrl?.replacingOccurrences(of: "playlist", with: "http") as NSString?
            let playlistUrl:NSString? = (NSURL(string: urlString as! String))?.absoluteString as NSString?
            
            RestConnector.startAsyncDownload(urlString: playlistUrl, progHandler:
                {(progress) in
                
                }, compHandler:
                { (response, errorCode) in
                    DispatchQueue.main.async(execute:
                    {
                        if (errorCode == TraceCode.TraceCodeSucces.rawValue)
                        {
                            if (playlistUrl?.range(of: ".ckf").location != NSNotFound) {
                                print("Assest Loader Called........")
                                let encryptionKey = Cache.getKey()!
                                let decryptedKey = AES.decrypt(data: response, key: encryptionKey)
                                
                                loadingRequest.dataRequest?.respond(with: decryptedKey)
                                loadingRequest.finishLoading()
                            }
                            else
                            {
                                var urlComponents:NSURLComponents = NSURLComponents(url: NSURL(playlistUrl), resolvingAgainstBaseURL: NO)
                                urlComponents.query = nil
                                var baseURL:NSString = urlComponents.url?.deletingLastPathComponent().absoluteString
                                
                                var m3u8Str:NSString = NSString(data: response, encoding: UTF8)
                                if (m3u8Str.range(of: ".m3u8").location != NSNotFound)
                                {
                                    let subReplace = "(\"[a-z0-9/:=~._-]*(\\.m3u8)\")"
                                    var error:NSError = nil
                                  
                                    do
                                    {
                                      var regX:NSRegularExpression = try NSRegularExpression(pattern: subReplace, options:NSRegularExpression.Options.caseInsensitive)
                                        m3u8Str = regX.replaceMatches(in: m3u8Str, options: NSRegularExpression.MatchingOptions.init(rawValue: 0), range: NSMakeRange(0, m3u8Str.length), withTemplate:"\"\(baseURL)^$1^\"")
                                        
                                        m3u8Str.replacingOccurrences(of:"^\"", with:"")
                                        m3u8Str.replacingOccurrences(of:"\"^", with:"")

                                    }
                                    catch {
                                        print("problem in REG X")
                                    }
                                }
                                else
                                {
                                    let subReplace = "([a-z0-9/:~._-]*(\\.ts|\\.webvtt|\\.vtt))"
                                    if (m3u8Str.range(of: "http").location != NSNotFound)
                                    {
                                        do
                                        {
                                            var regX:NSRegularExpression = try NSRegularExpression(pattern: subReplace, options:NSRegularExpression.Options.caseInsensitive)
                                            m3u8Str = regX.replaceMatches(in: m3u8Str, options: NSRegularExpression.MatchingOptions.init(rawValue: 0), range: NSMakeRange(0, m3u8Str.length), withTemplate:"\(baseURL)$1")
                                        }
                                        catch {
                                            print("problem in Segments")
                                        }
                                        if (m3u8Str.range(of:"key").location != NSNotFound)
                                        {
                                            let ckfReplace = "([a-z0-9/:~._-]*(\\.ts|\\.webvtt|\\.vtt))"
                                            urlComponents.scheme = urlComponents.scheme?.replacingOccurrences(of: "http", with: "playlist")
                                            do
                                            {
                                                regX = try NSRegularExpression(pattern: ckfReplace, options:NSRegularExpression.Options.caseInsensitive)
                                                baseURL = urlComponents.url?.deletingLastPathComponent().absoluteString
                                                m3u8Str = regX.replaceMatches(in: m3u8Str, options: NSRegularExpression.MatchingOptions.init(rawValue: 0), range: NSMakeRange(0, m3u8Str.length), withTemplate:"\(baseURL)$1")
                                            }
                                            catch {
                                                print("problem in Segments")
                                            }
                                        }
                                        else {
                                           m3u8Str.replacingOccurrences(of:"key", with:"playlist")
                                        }
                                    }
                                    else {
                                        m3u8Str.replacingOccurrences(of:"key", with:"playlist")
                                    }
                                }
                                print("m3u8Str....\(m3u8Str)")
                                loadingRequest.dataRequest?.respond(with: decryptedKey)
                                loadingRequest.finishLoading()
                            }
                        }
                        else {
                            print("error in key response\(response)");
                        }
                    })
                })
            return true
        }
        return true
    }
    
    func play(sender:Any) -> Void {
        self.player?.rate = playSpeedRate!
    }
    
    func pause(sender:Any) -> Void {
        self.player?.pause()
    }
    
    func getCurrentTime() -> CMTime {
        return (self.player?.currentTime())!
    }
    
    private func addObserver() -> Void
    {
        self.removeObserver()
        self.player?.addObserver(self, forKeyPath:"currentItem.playbackBufferEmpty", options:NSKeyValueObservingOptions.new, context:&kBufferEmptyKVO)
        self.player?.addObserver(self, forKeyPath:"airPlayVideoActive", options:NSKeyValueObservingOptions.new, context:&kAirplayKVO)
        self.player?.addObserver(self, forKeyPath:"currentItem.status", options:NSKeyValueObservingOptions.new, context:&kStatusDidChangeKVO)
        self.player?.addObserver(self, forKeyPath:"currentItem.loadedTimeRanges", options:NSKeyValueObservingOptions.new, context:&kTimeRangesKVO)
        self.player?.addObserver(self, forKeyPath:"currentItem.playbackLikelyToKeepUp", options:NSKeyValueObservingOptions.new, context:&kBufferKeepup)
        
    }
    
    private func removeObserver() -> Void
    {
        player?.removeObserver(self, forKeyPath:"currentItem.playbackBufferEmpty", context:&kBufferEmptyKVO)
        player?.removeObserver(self, forKeyPath:"airPlayVideoActive", context:&kAirplayKVO)
        player?.removeObserver(self, forKeyPath:"currentItem.status", context:&kStatusDidChangeKVO)
        player?.removeObserver(self, forKeyPath:"currentItem.loadedTimeRanges", context:&kTimeRangesKVO)
        player?.removeObserver(self, forKeyPath:"currentItem.playbackLikelyToKeepUp", context:&kBufferKeepup)
        
        if playerTimeObserver != nil {
            self.player?.removeTimeObserver(playerTimeObserver)
        }
        
        playerTimeObserver = nil
    }
    
    func cleanUp() -> Void
    {
        self.removeObserver()
        self.player?.pause()
        self.player?.removeAllItems()
        
        delegate = nil
    }
    
    deinit
    {
        self.removeObserver()
        self.playerTimeObserver = nil
        self.player = nil
    }
}
