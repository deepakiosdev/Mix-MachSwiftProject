//
//  RestConnector.swift
//  SecurePlayer
//
//  Created by Sharad Rao on 16/09/16.
//  Copyright © 2016 Sharad Rao. All rights reserved.
//

import UIKit

let TimeOutIntervalRequest  = 60.0
let TimeOutIntervalResource = 60.0

typealias CompletionHandler = (_ receivedObj:NSData?, _ errorCode:CLong) -> Void
typealias ProgressHandler = (_ progressValue:CGFloat) -> Void
typealias downloadData = (_ data:NSData) -> Void

protocol RestDelegate
{
    func downloadFailedWithError(connection:Any, withErrorCode errorCode:CLong) -> Void
    func downloadCompleted(connection:Any, withLocation location:NSURL) -> Void
    func downloadProgess(connection:Any, withProgress progress:CGFloat) -> Void
}

class RestConnector: NSObject
{
    var urlString:NSString?
    var session:URLSession?
    var sessionTask:URLSessionTask?
    
    //var progressHand:(_ progressValue:CGFloat) -> Void
    
    func startAsyncTask(urlMethod:NSString?, params:NSDictionary?,progHandler:ProgressHandler, compHandler:CompletionHandler) -> Void {
        
    }
    
    func configurationSeessionData() -> Void {
        
        let configuration = URLSessionConfiguration.default
        configuration.httpAdditionalHeaders = ["Accept":"application/json","Content-Type":"application/json"]
        configuration.allowsCellularAccess = true
        configuration.timeoutIntervalForRequest = TimeOutIntervalRequest
        configuration.timeoutIntervalForResource = TimeOutIntervalResource
        configuration.httpMaximumConnectionsPerHost = 1
        
        session = URLSession.init(configuration: configuration)
    }
    
   class func startAsyncDownload(urlString:NSString?, progHandler:ProgressHandler, compHandler:CompletionHandler) -> Void
    {
        let reachability = Reachability()
        if urlString?.range(of: "127.0.0.1:8080").location == NSNotFound {
            if !(reachability?.isReachable)! {
                compHandler(nil, TraceCode.TraceCodeNetworkError.rawValue)
                return
            }
        }
    }
    
    
}
