//
//  ViewController.swift
//  SecurePlayer
//
//  Created by Sharad Rao on 16/09/16.
//  Copyright © 2016 Sharad Rao. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var queuePlayer: QueuePlayer!
    
    override func viewDidLoad() {
      
        let urlString = "http://nmstream2.clearhub.tv/nmdcMaa/20130713/others/30880d62-2c5b-4487-8ff1-5794d086bea7.mp4"
        queuePlayer.initWithURLString(url: urlString as NSString?, andDelegate: self)
        
        
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

