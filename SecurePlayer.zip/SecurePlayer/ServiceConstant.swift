//
//  ServiceConstant.swift
//  SecurePlayer
//
//  Created by Sharad Rao on 16/09/16.
//  Copyright © 2016 Sharad Rao. All rights reserved.
//

import Foundation

enum TraceCode: CLong {

    case TraceCodeSucces
    case TraceCodeNetworkNotAvailable
    case TraceCodeNetworkError
    case TraceCodeAuthTokenExpired
    case TraceCodeReqJSONParseFailed
    case TraceCodeResJSONParseFailed
    case TraceCodeTaskSessionResumeSuccess
    case TraceCodeTaskSessionResumeFailed
    case TraceCodeTaskSessionPauseSuccess
    case TraceCodeTaskSessionPauseFailed
    case TraceCodeTaskSessionCancelSuccess
    case TraceCodeTaskSessionCancelFailed
    case TraceCodeFileSystemError
    case TraceCodeDataInitFailed
    case TraceCodeCustomError
}
